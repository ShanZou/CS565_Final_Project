//
//  AlbumCollectionViewCell.h
//  VeriFace
//
//  Created by chenshaoqiu on 2018/5/1.
//  Copyright © 2018年 lazy_boy. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AlbumCollectionViewCell : UICollectionViewCell

-(void)setImageUrl:(NSData *)imageData;

@end
