//
//  MPSkewedCollectionViewLayout.h
//  MPSkewed
//
//  Created by Alex Manzella on 17/05/15.
//  Copyright (c) 2015 Alex Manzella. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MPSkewedParallaxLayout : UICollectionViewFlowLayout

@property (nonatomic, assign) CGFloat lineSpacing;

@end
