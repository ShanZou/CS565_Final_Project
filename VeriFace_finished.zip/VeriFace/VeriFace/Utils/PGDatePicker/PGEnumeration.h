//
//  PGEnumeration.h
//
//  Created by piggybear on 2018/1/7.
//  Copyright © 2018年 piggybear. All rights reserved.
//

#ifndef PGEnumeration_h
#define PGEnumeration_h

typedef NS_ENUM(NSUInteger, PGDatePickManagerStyle) {
    PGDatePickManagerStyle1,
    PGDatePickManagerStyle2,
    PGDatePickManagerStyle3
};

#endif /* PGEnumeration_h */
