//
//  CheckInViewController.h
//  VeriFace
//
//  Created by chenshaoqiu on 2018/4/23.
//  Copyright © 2018年 lazy_boy. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CheckInViewController : UITableViewController

@end
